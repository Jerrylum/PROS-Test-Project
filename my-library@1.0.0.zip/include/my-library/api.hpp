#pragma once

#include "api.h"

void my_function();